import Foundation

struct GraphicDocumentPayload: Codable {
    var version: Int?
    var imageName: String?
    var sourceName: String?
    var canvasWidth: Int?
    var canvasHeight: Int?
    var drawingDataBase64: String?
    var backgroundImageBase64: String?
    var imageObjects: [CanvasImageObject]?
    var pencil: PencilPayload?
    var renamedFrom: String?

    enum CodingKeys: String, CodingKey {
        case version
        case imageName = "image_name"
        case sourceName = "source_name"
        case canvasWidth = "canvas_width"
        case canvasHeight = "canvas_height"
        case drawingDataBase64 = "drawing_data_base64"
        case backgroundImageBase64 = "background_image_base64"
        case imageObjects = "image_objects"
        case pencil
        case renamedFrom = "renamed_from"
    }
}

struct PencilPayload: Codable {
    var width: Double?
    var color: String?
}

struct GraphicEnvelope: Codable {
    var type: String
    var path: String?
    var operation: String?
    var message: String?
    var document: GraphicDocumentPayload?
    var pngBase64: String?
    var clientRevision: Int?
    var source: String?
    var previewPNGBase64: String?
    var deliveryID: String?

    enum CodingKeys: String, CodingKey {
        case type, path, operation, message, document, source
        case pngBase64 = "png_base64"
        case clientRevision = "client_revision"
        case previewPNGBase64 = "preview_png_base64"
        case deliveryID = "delivery_id"
    }
}
