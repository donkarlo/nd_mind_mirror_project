import UIKit

/// Erases pixels from an aspect-fit background image along a Pencil path while preserving image dimensions.
final class RasterBackgroundEraser {
    func erase(
        image: UIImage,
        canvasSize: CGSize,
        points: [CGPoint],
        brushDiameter: CGFloat
    ) -> UIImage? {
        guard points.count >= 1,
              image.size.width > 0,
              image.size.height > 0,
              canvasSize.width > 0,
              canvasSize.height > 0 else { return image }

        let fit = aspectFitRect(imageSize: image.size, canvasSize: canvasSize)
        let mapped = points.compactMap { point -> CGPoint? in
            guard fit.insetBy(dx: -brushDiameter, dy: -brushDiameter).contains(point) else { return nil }
            return CGPoint(
                x: (point.x - fit.minX) / max(fit.width, 1) * image.size.width,
                y: (point.y - fit.minY) / max(fit.height, 1) * image.size.height
            )
        }
        guard !mapped.isEmpty else { return image }

        let widthScale = image.size.width / max(fit.width, 1)
        let heightScale = image.size.height / max(fit.height, 1)
        let imageBrushDiameter = max(1, brushDiameter * max(widthScale, heightScale))

        let format = UIGraphicsImageRendererFormat.default()
        format.scale = image.scale
        format.opaque = false
        let renderer = UIGraphicsImageRenderer(size: image.size, format: format)
        return renderer.image { rendererContext in
            image.draw(in: CGRect(origin: .zero, size: image.size))
            let context = rendererContext.cgContext
            context.saveGState()
            context.setBlendMode(.clear)
            context.setLineCap(.round)
            context.setLineJoin(.round)
            context.setLineWidth(imageBrushDiameter)
            if mapped.count == 1, let point = mapped.first {
                let radius = imageBrushDiameter / 2
                context.fillEllipse(in: CGRect(
                    x: point.x - radius,
                    y: point.y - radius,
                    width: imageBrushDiameter,
                    height: imageBrushDiameter
                ))
            } else if let first = mapped.first {
                context.beginPath()
                context.move(to: first)
                for point in mapped.dropFirst() { context.addLine(to: point) }
                context.strokePath()
            }
            context.restoreGState()
        }
    }

    private func aspectFitRect(imageSize: CGSize, canvasSize: CGSize) -> CGRect {
        let scale = min(canvasSize.width / imageSize.width, canvasSize.height / imageSize.height)
        let fittedSize = CGSize(width: imageSize.width * scale, height: imageSize.height * scale)
        return CGRect(
            x: (canvasSize.width - fittedSize.width) / 2,
            y: (canvasSize.height - fittedSize.height) / 2,
            width: fittedSize.width,
            height: fittedSize.height
        )
    }
}
