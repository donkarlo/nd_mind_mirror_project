import PencilKit
import SwiftUI
import UIKit

/// Owns active tool state, applies selections immediately, and manages raster erasing.
@MainActor
final class ActiveDrawingToolController: NSObject, ObservableObject, UIGestureRecognizerDelegate {
    struct State: Equatable {
        var kind: GraphicTool
        var colorHex: String
        var width: Double
        var opacity: Double
        var eraserMode: EraserMode
        var selectedSavedToolID: UUID?
    }

    @Published private(set) var state = State(
        kind: .pencil,
        colorHex: "#000000",
        width: 1.5,
        opacity: 1.0,
        eraserMode: .whole,
        selectedSavedToolID: nil
    )
    @Published private(set) var isRasterEditing = false

    private weak var canvas: PKCanvasView?
    private weak var backgroundView: UIImageView?
    private var rasterGesture: UIPanGestureRecognizer?
    private let rasterEraser = RasterBackgroundEraser()
    private var rasterWorkingImage: UIImage?
    private var rasterStartImage: UIImage?
    private var previousRasterPoint: CGPoint?
    private var rasterDidChange = false
    private var canvasSize = CGSize(width: 1240, height: 1754)
    private var backgroundImageChanged: ((UIImage?) -> Void)?
    private var undoManagerChanged: ((UndoManager?) -> Void)?

    var kind: GraphicTool { state.kind }
    var color: Color { Color(hex: state.colorHex) }
    var width: Double { state.width }
    var opacity: Double { state.opacity }
    var eraserMode: EraserMode { state.eraserMode }
    var selectedSavedToolID: UUID? { state.selectedSavedToolID }
    var pencilSettings: PencilSettings { PencilSettings(width: state.width, color: color) }

    /// Attaches the controller directly to the live canvas. No window-tree lookup is used.
    func attach(canvas: PKCanvasView, backgroundView: UIImageView) {
        if self.canvas !== canvas {
            if let oldGesture = rasterGesture, let oldView = oldGesture.view {
                oldView.removeGestureRecognizer(oldGesture)
            }
            rasterGesture = nil
        }
        self.canvas = canvas
        self.backgroundView = backgroundView
        canvas.undoManager?.levelsOfUndo = 0
        configureParentScrollView(for: canvas)
        attachRasterEraserIfNeeded(to: canvas)
        applyImmediately()
    }

    func bindRuntime(
        canvasSize: CGSize,
        backgroundImageChanged: @escaping (UIImage?) -> Void,
        undoManagerChanged: @escaping (UndoManager?) -> Void
    ) {
        self.canvasSize = canvasSize
        self.backgroundImageChanged = backgroundImageChanged
        self.undoManagerChanged = undoManagerChanged
        applyImmediately()
    }

    func select(savedTool: SavedDrawingTool) {
        let selectedWidth = savedTool.kind == .eraser
            ? canonicalEraserWidth(savedTool.width)
            : canonicalInkWidth(savedTool.width)
        setState(State(
            kind: savedTool.kind,
            colorHex: canonicalColor(savedTool.colorHex),
            width: selectedWidth,
            opacity: canonicalOpacity(savedTool.opacity),
            eraserMode: savedTool.eraserMode,
            selectedSavedToolID: savedTool.id
        ))
    }

    func select(kind: GraphicTool) {
        var next = state
        next.kind = kind
        next.selectedSavedToolID = nil
        setState(next)
    }

    func updateAppearance(color: Color? = nil, width: Double? = nil, opacity: Double? = nil) {
        var next = state
        if let color { next.colorHex = canonicalColor(color.hexRGB()) }
        if let width {
            next.width = next.kind == .eraser
                ? canonicalEraserWidth(width)
                : canonicalInkWidth(width)
        }
        if let opacity { next.opacity = canonicalOpacity(opacity) }
        next.selectedSavedToolID = nil
        setState(next)
    }

    func adoptDocumentPencil(width: Double?, colorHex: String?) {
        guard state.selectedSavedToolID == nil, state.kind != .eraser else { return }
        var next = state
        if let width { next.width = canonicalInkWidth(width) }
        if let colorHex, !colorHex.isEmpty { next.colorHex = canonicalColor(colorHex) }
        setState(next)
    }

    func isSelected(_ savedTool: SavedDrawingTool) -> Bool {
        state.selectedSavedToolID == savedTool.id
    }

    private func setState(_ next: State) {
        state = next
        applyImmediately()
    }

    private func configureParentScrollView(for canvas: PKCanvasView) {
        var parent = canvas.superview
        while let view = parent {
            if let scroll = view as? UIScrollView, scroll !== canvas {
                scroll.panGestureRecognizer.minimumNumberOfTouches = 2
                scroll.panGestureRecognizer.maximumNumberOfTouches = 2
                scroll.panGestureRecognizer.allowedTouchTypes = [NSNumber(value: UITouch.TouchType.direct.rawValue)]
                break
            }
            parent = view.superview
        }
    }

    private func applyImmediately() {
        guard let canvas else { return }
        switch state.kind {
        case .pencil:
            canvas.tool = PKInkingTool(
                .pencil,
                color: UIColor(color).withAlphaComponent(CGFloat(state.opacity)),
                width: CGFloat(state.width)
            )
        case .highlighter:
            canvas.tool = PKInkingTool(
                .marker,
                color: UIColor(color).withAlphaComponent(CGFloat(state.opacity)),
                width: CGFloat(state.width)
            )
        case .eraser:
            let type: PKEraserTool.EraserType = state.eraserMode == .partial ? .bitmap : .vector
            canvas.tool = PKEraserTool(type, width: CGFloat(state.width))
        case .lasso:
            canvas.tool = PKLassoTool()
        }
        rasterGesture?.isEnabled = state.kind == .eraser
    }

    private func attachRasterEraserIfNeeded(to canvas: PKCanvasView) {
        if let rasterGesture, rasterGesture.view === canvas {
            rasterGesture.isEnabled = state.kind == .eraser
            return
        }
        let gesture = UIPanGestureRecognizer(target: self, action: #selector(handleRasterErase(_:)))
        gesture.allowedTouchTypes = [NSNumber(value: UITouch.TouchType.pencil.rawValue)]
        gesture.maximumNumberOfTouches = 1
        gesture.cancelsTouchesInView = false
        gesture.delegate = self
        gesture.isEnabled = state.kind == .eraser
        canvas.addGestureRecognizer(gesture)
        rasterGesture = gesture
    }

    @objc private func handleRasterErase(_ gesture: UIPanGestureRecognizer) {
        guard state.kind == .eraser, let canvas, let backgroundView else { return }
        let point = gesture.location(in: canvas)

        switch gesture.state {
        case .began:
            isRasterEditing = true
            rasterStartImage = backgroundView.image
            rasterWorkingImage = backgroundView.image
            previousRasterPoint = point
            rasterDidChange = false
            eraseRasterSegment(from: point, to: point, backgroundView: backgroundView)
        case .changed:
            let previous = previousRasterPoint ?? point
            eraseRasterSegment(from: previous, to: point, backgroundView: backgroundView)
            previousRasterPoint = point
        case .ended:
            let previous = previousRasterPoint ?? point
            eraseRasterSegment(from: previous, to: point, backgroundView: backgroundView)
            let original = rasterStartImage
            let final = rasterWorkingImage
            if rasterDidChange {
                registerRasterUndo(original: original, final: final)
                backgroundImageChanged?(final)
            }
            clearRasterSession()
        case .cancelled, .failed:
            backgroundView.image = rasterStartImage
            clearRasterSession()
        default:
            break
        }
    }

    private func eraseRasterSegment(from start: CGPoint, to end: CGPoint, backgroundView: UIImageView) {
        guard let source = rasterWorkingImage,
              let erased = rasterEraser.erase(
                image: source,
                canvasSize: canvasSize,
                points: [start, end],
                brushDiameter: max(2, CGFloat(state.width))
              ) else { return }
        rasterWorkingImage = erased
        rasterDidChange = true
        backgroundView.image = erased
    }


    private func registerRasterUndo(original: UIImage?, final: UIImage?) {
        guard let manager = canvas?.undoManager else { return }
        manager.levelsOfUndo = 0
        manager.registerUndo(withTarget: self) { target in
            target.restoreRasterImage(original, reciprocal: final)
        }
        manager.setActionName("Erase Image")
        undoManagerChanged?(manager)
    }

    private func restoreRasterImage(_ image: UIImage?, reciprocal: UIImage?) {
        guard let backgroundView else { return }
        backgroundView.image = image
        backgroundImageChanged?(image)
        if let manager = canvas?.undoManager {
            manager.levelsOfUndo = 0
            manager.registerUndo(withTarget: self) { target in
                target.restoreRasterImage(reciprocal, reciprocal: image)
            }
            manager.setActionName("Erase Image")
            undoManagerChanged?(manager)
        }
    }

    func gestureRecognizer(
        _ gestureRecognizer: UIGestureRecognizer,
        shouldRecognizeSimultaneouslyWith otherGestureRecognizer: UIGestureRecognizer
    ) -> Bool {
        gestureRecognizer === rasterGesture || otherGestureRecognizer === rasterGesture
    }

    private func clearRasterSession() {
        rasterWorkingImage = nil
        rasterStartImage = nil
        previousRasterPoint = nil
        rasterDidChange = false
        isRasterEditing = false
    }

    private func canonicalColor(_ raw: String) -> String {
        var value = raw.trimmingCharacters(in: .whitespacesAndNewlines).uppercased()
        if value.hasPrefix("#") { value.removeFirst() }
        if value.count == 8 { value = String(value.prefix(6)) }
        guard value.count == 6, value.allSatisfy(\.isHexDigit) else { return "#000000" }
        return "#\(value)"
    }

    private func canonicalInkWidth(_ value: Double) -> Double {
        min(max(value.isFinite ? value : 1.5, 0.5), 60)
    }

    private func canonicalEraserWidth(_ value: Double) -> Double {
        min(max(value.isFinite ? value : 18, 2), 120)
    }

    private func canonicalOpacity(_ value: Double) -> Double {
        min(max(value.isFinite ? value : 1, 0.05), 1)
    }
}
