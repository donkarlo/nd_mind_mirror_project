import Foundation
import SwiftUI

@main
struct NDGraphicApp: App {
    var body: some Scene {
        WindowGroup {
            NDGraphicBootstrapView()
        }
    }
}

/// Render a lightweight first frame before the graphic stack starts.
/// Swift Playgrounds can then initialize PencilKit and networking without
/// coupling them to the host's first rendering pass.
struct NDGraphicBootstrapView: View {
    @State private var openWorkspace = false

    private var displayVersion: String {
        Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString") as? String ?? "unknown"
    }

    var body: some View {
        ZStack {
            Color.indigo
                .ignoresSafeArea()

            if openWorkspace {
                ContentView()
                    .background(Color.white)
            } else {
                VStack(spacing: 24) {
                    Image(systemName: "brain.head.profile")
                        .font(.system(size: 76, weight: .semibold))
                    Text("ND Graphic \(displayVersion)")
                        .font(.system(size: 38, weight: .bold))
                    Text("Mind Mirror iPad graphic editor")
                        .font(.title3)
                    ProgressView()
                        .tint(.white)
                }
                .foregroundStyle(.white)
                .padding(40)
            }
        }
        .task {
            guard !openWorkspace else { return }
            await Task.yield()
            openWorkspace = true
        }
    }
}
